from django.apps import AppConfig


class TablerappConfig(AppConfig):
    name = 'tablerapp'
